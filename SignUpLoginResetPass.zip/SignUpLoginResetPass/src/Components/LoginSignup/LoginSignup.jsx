import './LoginSignup.css';
import React, { useState } from 'react';

import user_icon from '../Assets/person.png';
import email_icon from '../Assets/email.png';
import password_icon from '../Assets/password.png';
import logo from '../Assets/SAGEA_affiliate-logos_Eduvos1-removebg-preview.png';

const LoginSignup = () => {
  const [action, setAction] = useState("Sign Up");
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [email, setEmail] = useState("");

  const handleForgotPasswordClick = () => {
    setShowForgotPassword(true);
  };

  const handleBackToLogin = () => {
    setShowForgotPassword(false);
    setAction("Login");
  };

  const handleResetSubmit = () => {
    alert(`Password reset link sent to: ${email}`);
    setShowForgotPassword(false);
    setAction("Login");
  };

  return (
    <div className='container'>
      {/* ✅ Logo + App Name + Slogan */}
      <div className="logo-container">
        <img src={logo} alt="App Logo" className="logo" />
        <h1 className="app-name">EduVate</h1>
        <p className="slogan">Where Ideas, Drive Change</p>
      </div>

      {/* Forgot Password Form */}
      {showForgotPassword ? (
        <div className="forgot-password-container">
          <div className="header">
            <div className="text">Forgot Password</div>
            <div className="underline"></div>
          </div>

          <div className='inputs'>
            <div className='input'>
              <img src={email_icon} alt="" />
              <input 
                type="email" 
                placeholder='Enter your email' 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
          </div>

          <div className='submit-container'>
            <div className='submit' onClick={handleResetSubmit}>Send Reset Link</div>
            <div className='submit gray' onClick={handleBackToLogin}>Back to Login</div>
          </div>
        </div>
      ) : (
        <>
          {/* Normal Login/Signup Form */}
          <div className="header">
            <div className="text">{action}</div>
            <div className="underline"></div>
          </div>

          <div className='inputs'>
            {action === "Login" ? null : (
              <div className='input'>
                <img src={user_icon} alt="" />
                <input type="text" placeholder='Full Name' />
              </div>
            )}

            <div className='input'>
              <img src={email_icon} alt="" />
              <input type="email" placeholder='Email ID' />
            </div>

            <div className='input'>
              <img src={password_icon} alt="" />
              <input type="password" placeholder='Password' />
            </div>
          </div>

          {action === "Sign Up" ? null : (
            <div className='forgot-password'>
              Lost Password? <span onClick={handleForgotPasswordClick}>Click Here!</span>
            </div>
          )}

          <div className='submit-container'>
            <div 
              className={action === "Login" ? "submit gray" : "submit"} 
              onClick={() => setAction("Sign Up")}
            >
              Sign Up
            </div>
            <div 
              className={action === "Sign Up" ? "submit gray" : "submit"} 
              onClick={() => setAction("Login")}
            >
              Login
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default LoginSignup;
