
import './App.css';
import LoginSignup from './Components/LoginSignup/LoginSignup.jsx';

function App() {
  return (
    <div>
      <LoginSignup/>
    </div>
  );
}

export default App;
